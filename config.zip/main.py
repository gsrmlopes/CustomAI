from typing import Dict
import sys
import json
from src.models import GeneticAlgorithm
from src.utils.loggers import info_logger, error_logger

def load_config(config_path: str) -> Dict:
    """
    Load the JSON configuration from the given path.

    Parameters:
    - config_path (str): The path to the JSON configuration file.

    Returns:
    - dict: The loaded configuration.
    """
    try:
        with open(config_path) as f:
            return json.load(f)
    except FileNotFoundError:
        error_logger.error("Could not find config.json.")
        sys.exit(1)
    except json.JSONDecodeError:
        error_logger.error("Could not decode JSON in config.json.")
        sys.exit(1)

def main(config: Dict):
    """
    The main function runs a genetic algorithm until certain metrics are met.
    
    Parameters:
    - config (Dict): Configuration dictionary.
    """
    passable_metrics = False
    runs = 0

    info_logger.info("Starting Genetic Algorithm.")
    info_logger.info("Running until %s generations.", config["max_Generations"])
    info_logger.info("Population size: %s", config["population_Size"])
    info_logger.info("Batch size: %s", config["batch_Size"])

    while not passable_metrics:
        runs += 1
        info_logger.info("Run #%d", runs)
        
        ga = GeneticAlgorithm(config["population_Size"])
        info_logger.info("Genetic Algorithm created.")
        info_logger.info("Starting Genetic Algorithm.")
        
        loopable = ga.run()
        
        info_logger.info("Genetic Algorithm finished.")
        if loopable:
            passable_metrics = loopable

if __name__ == "__main__":
    config_path = "D:/_Projetos/Python/customAI/config/config.json"
    config = load_config(config_path)
    main(config)
