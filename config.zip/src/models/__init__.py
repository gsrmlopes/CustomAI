# src/models/__init__.py
from .custom_model import *
from .genetic_algorithm import *
